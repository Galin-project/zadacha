using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace NoteApp
{
    public partial class Form1 : Form
    {
        private List<Note> notes = new List<Note>();
        private string filePath = "notes.json";

        public Form1()
        {
            InitializeComponent();
            LoadNotes();
            UpdateListBox();
        }

        private void LoadNotes()
        {
            if (File.Exists(filePath))
            {
                string json = File.ReadAllText(filePath);
                notes = JsonSerializer.Deserialize<List<Note>>(json);
            }
        }

        private void SaveNotes()
        {
            string json = JsonSerializer.Serialize(notes);
            File.WriteAllText(filePath, json);
        }

        private void UpdateListBox()
        {
            listBoxNotes.Items.Clear();
            foreach (var note in notes.OrderBy(n => n.CreatedAt))
            {
                listBoxNotes.Items.Add(note);
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBoxNote.Text))
            {
                notes.Add(new Note { Text = textBoxNote.Text, CreatedAt = DateTime.Now });
                textBoxNote.Clear();
                UpdateListBox();
            }
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            int index = listBoxNotes.SelectedIndex;
            if (index >= 0 && index < notes.Count)
            {
                notes[index].Text = textBoxNote.Text;
                UpdateListBox();
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            int index = listBoxNotes.SelectedIndex;
            if (index >= 0 && index < notes.Count)
            {
                notes.RemoveAt(index);
                textBoxNote.Clear();
                UpdateListBox();
            }
        }

        private void listBoxNotes_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = listBoxNotes.SelectedIndex;
            if (index >= 0 && index < notes.Count)
            {
                textBoxNote.Text = notes[index].Text;
            }
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            SaveNotes();
            base.OnFormClosing(e);
        }
    }

    public class Note
    {
        public string Text { get; set; }
        public DateTime CreatedAt { get; set; }

        public override string ToString()
        {
            return $"{CreatedAt:yyyy-MM-dd HH:mm} - {Text}";
        }
    }
}
